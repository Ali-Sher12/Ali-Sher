/////////////////////////////////////////////////
/////////////////////////////////////////////////
//                                             //
//              CLEANING NEEDED                //
//                                             //
/////////////////////////////////////////////////
/////////////////////////////////////////////////


#pragma once
using namespace std;

class HollowHeap:public ParentHeap
{
private:
    struct Node
    {
        double key;      // priority
        int value;       // graph node
        Node* child;     // first child
        Node* next;      // sibling
        Node* ep;        // extra parent (only for hollow nodes)
        int rank;        // rank of node
        bool hollow;     // meaning the node is ‘dead’

        Node(double k, int v)
        {
            key = k;
            value = v;
            child = nullptr;
            next = nullptr;
            ep = nullptr;
            rank = 0;
            hollow = false;
        }
    };

    Node* min_root = nullptr;

    // link child under parent
    Node* link(Node* a, Node* b)
    {
        if (b == nullptr) return a;
        if (a == nullptr) return b;

        if (a->key <= b->key)
        {
            b->next = a->child;
            a->child = b;
            return a;
        }
        else
        {
            a->next = b->child;
            b->child = a;
            return b;
        }
    }

    // Make a hollow version of a node
    void makeHollow(Node* x, Node* child)
    {
        x->hollow = true;
        x->child = child;
        if (child) child->ep = x;
    }

    // Dismantle hollow nodes and update min
    void clean()
    {
        unordered_map<int, Node*> rankTable;

        vector<Node*> roots;

        Node* cur = min_root;
        while (cur)
        {
            Node* nxt = cur->next;
            cur->next = nullptr;
            roots.push_back(cur);
            cur = nxt;
        }

        min_root = nullptr;

        while (!roots.empty())
        {
            Node* x = roots.back();
            roots.pop_back();

            if (x->hollow)
            {
                Node* c = x->child;
                while (c)
                {
                    Node* nxt = c->next;
                    if (c->ep == x) c->ep = nullptr;
                    roots.push_back(c);
                    c->next = nullptr;
                    c = nxt;
                }
                continue;
            }

            while (rankTable.count(x->rank))
            {
                Node* y = rankTable[x->rank];
                rankTable.erase(x->rank);
                x = link(x, y);
                x->rank++;
            }
            rankTable[x->rank] = x;
        }

        for (auto& p : rankTable)
        {
            min_root = link(min_root, p.second);
        }
    }

public:

    // NOTE: The heap doesn't use indexes, but your Dijkstra checks this map.
    // We store (value -> 1) if present.

    bool empty()
    {
        return (min_root == nullptr);
    }

    void insert(double key, int value)
    {
        Node* x = new Node(key, value);

        min_root = link(min_root, x);

        storage[value] = 1; // mark that this value is inside the heap

        if(profiling)
        {
            int h = computeHeight(min_root);
            if(h>profile_data[18])
                profile_data[18] = h;

            h = hollowHeapNumTrees();
            if(h>profile_data[19])
                profile_data[19] = h;                
        }    
    }

    int hollowHeapNumTrees() 
    {
        int count = 0;
        Node* curr = min_root;
        while (curr) {
            count++;
            curr = curr->next; // traverse root list
        }
        return count;
    }

    void decreaseKey(int value, double newKey)
    {
        if (!storage.count(value))
            return; // if node not found, skip

        Node* newNode = new Node(newKey, value);

        min_root = link(min_root, newNode);

        // We cannot delete directly (Hollow Heap uses laziness)
        // So: mark the old node hollow later.
        // We will hollow it when we find it during cleanup.

        // This is standard hollow-heap: we do NOT need to track original node
        // because lazy deletion fixes everything on ExtractMin.
    }

    BinHeapNode ExtractMin()
    {
        clean(); 

        if (!min_root)
        {
            return BinHeapNode{ (double)INT_MAX, -1 };
        }

        Node* old = min_root;

        Node* c = old->child;
        vector<Node*> children;

        while (c)
        {
            Node* nxt = c->next;
            c->next = nullptr;
            if (c->ep == old) c->ep = nullptr;
            children.push_back(c);
            c = nxt;
        }

        min_root = nullptr;

        unordered_map<int, Node*> rankTable;
        for (Node* x : children)
        {
            while (rankTable.count(x->rank))
            {
                Node* y = rankTable[x->rank];
                rankTable.erase(x->rank);
                x = link(x, y);
                x->rank++;
            }
            rankTable[x->rank] = x;
        }

        for (auto& p : rankTable)
        {
            min_root = link(min_root, p.second);
        }

        storage.erase(old->value);

        BinHeapNode ret;
        ret.key = old->key;
        ret.value = old->value;

        delete old;
        return ret;
    }
    // Recursive height helper
    int computeHeight(Node* x)
    {
        if (x == nullptr)
            return 0;  

        int maxChildHeight = 0;

        Node* c = x->child;
        while (c)
        {
            maxChildHeight = max(maxChildHeight, computeHeight(c));
            c = c->next;
        }

        return 1 + maxChildHeight;
    }


};

#pragma once
using namespace std;

class Edge
{
public:
	int toNode = -1;
	double weight = INT_MAX;
	void initializing(int t2, double t3)
	{
		toNode = t2;
		weight = t3;
	}
};

class Graph
{
	int loading_count = 0;
	int loading_count_ = 0;
	int gap = 10000;
	int jump = 10;

public:
	int total_vertices = 0;
	int total_edges = 0;
	vector<vector<Edge>> graph_list;

	void initialize(string file_name)
	{// a psuedo constructor

		ifstream file(file_name);
		file >> total_vertices >> total_edges;

		int temp1, temp2;
		double temp3;
		graph_list.resize(total_vertices);

		cout << "\t\n0/" << total_edges << "\n";
		cout << "\t\nReading.";
		while (file >> temp1 >> temp2 >> temp3)
		{
			Edge temp_edge;
			temp_edge.initializing(temp2, temp3);
			graph_list[temp1].push_back(temp_edge);
			if (loading_count % gap == 0)
				cout << ".";
			if (loading_count >= jump * gap)
			{
				loading_count_ += gap;
				loading_count = 0;
				system("clear");
				cout << "\t\n" << loading_count_ << "/" << total_edges << "\n";
				cout << "\t\nReading.";
			}

			loading_count++;
		}
		system("clear");
		cout << "\t\n" << total_edges << "/" << total_edges << "\n";
		cout << "\t\nData Successfully Read.";
		file.close();
	}

	bool insertEdge(int node,Edge e) 
	{
		if (e.toNode >= total_vertices || node >= total_vertices)
		{// after an hour, this condition was the issue. Thnx gpt.
			cout << "\nFailed to insert Edge.\n";
			return false;
		}
		total_edges++;
		graph_list[node].push_back(e);
		return true;
	}

	void setSizeInitially(int n) 
	{
		// Don't use this if graph has been set with initialize function
		total_vertices = n;
		graph_list.resize(n);
	}

	void test_print()
	{// straight from the depths of GPT
		cout << total_vertices << " " << total_edges << "\n";
		for (int i = 0;i < graph_list.size();i++)
		{
			cout << "\nFor node " << i << " :\n";
			for (int j = 0;j < graph_list[i].size();j++)
			{
				cout << "\ndebug\n";
				cout << graph_list[i][j].toNode << " " << graph_list[i][j].weight << "\n";
			}
		}
	}

};
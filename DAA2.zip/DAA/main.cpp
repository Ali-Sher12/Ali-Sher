#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits.h>
#include <unordered_map>
#include <cmath>
#include <filesystem>
#include <chrono>
#include "ParentHeap.h"
#include "Graph.h"
#include "BinaryHeap.h"
#include "FibHeap.h"
#include "HollowHeap.h"
#include "Dijikstra.h"
#include "visual.h"

void profile(vector<float> times,string dir,string name,int vertices,int edges,int edges_)
{
    ofstream out(dir+"Profile_"+name,ios::trunc);
    out <<"Profiling:\nTotal vertices = " << vertices << "\nTotal edges before = " << edges << "\n";
    out <<"Total edges after = " << edges_ << "\n";	
    out <<"\n\n0 may mean no data as well.\n";	    
    for(int i=0;i<3;i++)
    {
        if(i==0)
            out <<"\nBinary Heap : \n";	    
        else if(i==1)
            out <<"\nFibonacci Heap : \n";	    
        if(i==2)
            out <<"\nHollow : \n";	                            
        out <<"\tTotal Time = " << times[0+i] << "ns.\n";
        out <<"\tInsert Time = " << times[1+i] << "ns.\n";    
        out <<"\tExtract-Min Time = " << times[2+i] << "ns.\n";    
        out <<"\tDecreasy-key Time = " << times[3+i] << "ns.\n";    
        out <<"\tHeap Height = " << times[4+i] << ".\n";    
        out <<"\tTotal trees = " << times[5+i] << ".\n";                    
        out <<"\tMemory usage = " << times[6+i] << " MB.\n";    
    }
    out.close();
}
void getFiles(string dir,vector<string>& graphs)
{
    try 
	{
        for (auto entry : filesystem::directory_iterator(dir)) 
		{
            if (entry.is_regular_file()) 
			{
                auto p = entry.path();
                if (p.extension() == ".road-d") 
                    graphs.push_back(p.filename().string());
            }
        }
    }
    catch (filesystem::filesystem_error &e) 
	{
        std::cerr << "Error: " << e.what() << "\n";
    }
}



int main() 
{
	string directory_input = "Input_Graphs/";
	string directory_output = "Output_Graphs/";	
	vector<string> graphs;

	profile_data.resize(21);
    for(int i = 0; i < 21; i++)
        profile_data[i] = 0;

while(1)
{
    graphs.clear();
    system("clear");				
    int choice1 = 0;
    int choice2 = 0;	
    int choice3 = 0;			
    cout<<"\n\n\t\tDijakstra Algorithm with Automanage Heap\n";
    cout<<"\n\n\t\t1. Select Input Files.";
    cout<<"\n\n\t\t2. Exit.\n";
    cout<<"\n\n\t\t->";		
    cin >> choice1;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');  // <-- flush leftover newline
    system("clear");
    if(choice1 == 1)
    {
        do
        {
            getFiles(directory_input,graphs);
            cout<<"\n\n\t\tChoose file to process.\n";
            cout<<"\n\n\t\t"<<"0. Exit.";				
            for(int i=0;i<graphs.size();i++)
            {
                cout<<"\n\n\t\t"<< i+1 << ". "<< graphs[i];
            }
            cout<<"\n\n\t\t->";		
            cin >> choice2;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  // <-- flush leftover newline
            system("clear");				
        } while(!(choice2 >= 0 && choice2 <= graphs.size()));

        if(choice2!=0)
        {
            do
            {
                cout<<"\n\n\t\tHeap preference?\n";
                cout<<"\n\n\t\t1. Binary Heap.";
                cout<<"\n\n\t\t2. Fibonacci Heap.";
                cout<<"\n\n\t\t3. Hollow Heap.";				
                cout<<"\n\n\t\t4. Auto-Select based on conditions.";				
                cout<<"\n\n\t\t5. Profiling. (Does NOT save the output)";				
                cout<<"\n\n\t\t->";		
                cin >> choice3;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');  // <-- flush leftover newline
                system("clear");			
            } while(!(choice3 >= 1 && choice3<=5));				

			Graph g;
			Graph g_out;			
            if(choice3 == 5)
			{				
                profiling = true;
				g.initialize(directory_input+graphs[choice2-1]);
                auto_manage = 1;
				auto start = chrono::high_resolution_clock::now();
					g_out = dijkstraTree(g);
				auto end = chrono::high_resolution_clock::now();
				auto duration = chrono::duration_cast<chrono::nanoseconds>(end - start);
				profile_data[0] = duration.count();
                profile_data[5] = 1;

				auto_manage = 2;
				start = chrono::high_resolution_clock::now();
					g_out = dijkstraTree(g);
				end = chrono::high_resolution_clock::now();
				duration = chrono::duration_cast<chrono::nanoseconds>(end - start);
				profile_data[7] = duration.count();

				auto_manage = 3;								
				start = chrono::high_resolution_clock::now();
					g_out = dijkstraTree(g);
				end = chrono::high_resolution_clock::now();
				duration = chrono::duration_cast<chrono::nanoseconds>(end - start);
				profile_data[14] = duration.count();

				profile(profile_data,directory_output,graphs[choice2-1],g.total_vertices,g.total_edges,g_out.total_edges);
				cout<<"\n\n\t\tProfiling Complete!";						
				cout<<"\n\n\t\tPress Enter to continue->";		
				cin.ignore(numeric_limits<streamsize>::max(), '\n');  // wait for Enter
				continue;
			}

            else if(choice3 == 4)
                auto_manage = 4;
            else
                auto_manage = choice3;

            g.initialize(directory_input+graphs[choice2-1]);
            g_out = dijkstraTree(g);
            cout<<"\nWriting to file.\n";
            writeGraphToFile(g_out,graphs[choice2-1],directory_output);    
            cout<<"\nfinished.\n\n\n";
			visualise(g_out);
            cout<<"\n\n\t\tPress Enter to continue->";		
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  // wait for Enter
        }
    }
    else return 0;
}
	return 0;
}
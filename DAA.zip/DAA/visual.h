#pragma once

using namespace std;
using namespace sf;

vector<Vector2f> computeVertexPositions(int n, float width, float height) {
    vector<Vector2f> positions(n);
    float radius = min(width, height) / 2.5f;
    Vector2f center(width / 2.0f, height / 2.0f);

    for (int i = 0; i < n; i++) {
        float angle = 2 * M_PI * i / n;
        positions[i] = Vector2f(
            center.x + radius * cos(angle),
            center.y + radius * sin(angle)
        );
    }
    return positions;
}

// Draw edges of the graph
void drawEdges(RenderWindow &window, const Graph &G, const vector<Vector2f> &positions,
               const Color &color = Color::White) {

    for (int u = 0; u < G.total_vertices; u++) {
        for (Edge e : G.graph_list[u]) {
            Vertex line[2];
            line[0].position = positions[u];
            line[0].color = color;
            line[1].position = positions[e.toNode];
            line[1].color = color;

            window.draw(line, 2, PrimitiveType::Lines);
        }
    }
}

// Draw nodes of the graph
void drawNodes(RenderWindow &window, const vector<Vector2f> &positions,
               const Color &color = Color::Green, float radius = 15.0f) {

    int i=0;
    Font font;
    sf::Text text(font,"kill me",10);
    if (!font.openFromFile("arial.ttf")) {
        std::cerr << "Error loading font!" << std::endl;
        return;
    }
    for (auto &pos : positions) {

        text.setFont(font);
        text.setString(to_string(i));
        text.setCharacterSize(30); // pixels
        text.setFillColor(sf::Color::Blue);
        text.setPosition(Vector2f(pos.x - radius/2, pos.y - radius/1.5));        
        CircleShape circle(radius);
        circle.setOrigin(Vector2f(radius, radius)); // center the circle
        circle.setPosition(pos);
        circle.setFillColor(color);
        window.draw(circle);
        window.draw(text);
        i++;
    }
}

// Visualize the graph
void visualise(const Graph &G) 
{
    // if(G.total_vertices > 20)
    //     return;
    
    RenderWindow window(VideoMode({1000, 800}), "Graph Visualization", Style::Close);
    window.setFramerateLimit(60); // Optional: limits CPU usage

    vector<Vector2f> positions = computeVertexPositions(G.total_vertices, 1000, 800);

    Color nodeColor = Color::Green;
    Color edgeColor = Color::White;

    while (window.isOpen()) 
    {
        // 1. ADD THE EVENT PROCESSING LOOP HERE
        while (const std::optional event = window.pollEvent()) 
        {
            // Check if the user requested to close the window (e.g., clicking 'X')
            if (event->is<sf::Event::Closed>())
            {
                window.close();
            }
        }
        // ------------------------------------------

        // 2. Clear, Draw, and Display
        window.clear(Color::Black);

        drawEdges(window, G, positions, edgeColor);
        drawNodes(window, positions, nodeColor, 20.0f);

        window.display();
    }
}
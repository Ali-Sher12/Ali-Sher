#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits.h>
#include <unordered_map>
#include <cmath>
#include <filesystem>
#include "ParentHeap.h"
#include "Graph.h"
#include "BinaryHeap.h"
#include "FibHeap.h"
#include "HollowHeap.h"
#include "Dijikstra.h"
#include "visual.h"

void getFiles(string dir,vector<string>& graphs)
{
    try 
	{
        for (auto entry : filesystem::directory_iterator(dir)) 
		{
            if (entry.is_regular_file()) 
			{
                auto p = entry.path();
                if (p.extension() == ".road-d") 
                    graphs.push_back(p.filename().string());
            }
        }
    }
    catch (filesystem::filesystem_error &e) 
	{
        std::cerr << "Error: " << e.what() << "\n";
    }
}



int main() 
{
	string directory_input = "Input_Graphs/";
	string directory_output = "Output_Graphs/";	
	vector<string> graphs;
while(1)
{
    graphs.clear();
    system("clear");				
    int choice1 = 0;
    int choice2 = 0;	
    int choice3 = 0;			
    cout<<"\n\n\t\tDijakstra Algorithm with Automanage Heap\n";
    cout<<"\n\n\t\t1. Select Input Files.";
    cout<<"\n\n\t\t2. Exit.\n";
    cout<<"\n\n\t\t->";		
    cin >> choice1;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');  // <-- flush leftover newline
    system("clear");
    if(choice1 == 1)
    {
        do
        {
            getFiles(directory_input,graphs);
            cout<<"\n\n\t\tChoose file to process.\n";
            cout<<"\n\n\t\t"<<"0. Exit.";				
            for(int i=0;i<graphs.size();i++)
            {
                cout<<"\n\n\t\t"<< i+1 << ". "<< graphs[i];
            }
            cout<<"\n\n\t\t->";		
            cin >> choice2;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  // <-- flush leftover newline
            system("clear");				
        } while(!(choice2 >= 0 && choice2 <= graphs.size()));

        if(choice2!=0)
        {
            do
            {
                cout<<"\n\n\t\tHeap preference?\n";
                cout<<"\n\n\t\t1. Binary Heap.";
                cout<<"\n\n\t\t2. Fibonacci Heap.";
                cout<<"\n\n\t\t3. Hollow Heap.";				
                cout<<"\n\n\t\t4. Auto-Select based on conditions.";				
                cout<<"\n\n\t\t->";		
                cin >> choice3;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');  // <-- flush leftover newline
                system("clear");			
            } while(!(choice3 >= 1 && choice3<=4));				

            if(choice3 == 4)
                auto_manage = 4;
            else
                auto_manage = choice3;

            Graph g;
            g.initialize(directory_input+graphs[choice2-1]);
            g = dijkstraTree(g);
            cout<<"\nWriting to file.\n";
            writeGraphToFile(g,graphs[choice2-1],directory_output);    
            cout<<"\nfinished.\n\n\n";
			visualise(g);
            cout<<"\n\n\t\tPress Enter to continue->";		
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  // wait for Enter
        }
    }
    else return 0;
}
	return 0;
}

/////////////////////////////////////////////////
/////////////////////////////////////////////////
//                                             //
//              CLEANING NEEDED                //
//                                             //
/////////////////////////////////////////////////
/////////////////////////////////////////////////

#pragma once
using namespace std;

class FibHeap : public ParentHeap
{
private:
    struct FibNode
    {
        double key;
        int value;

        int degree = 0;
        bool marked = false;

        FibNode* parent = nullptr;
        FibNode* child = nullptr;
        FibNode* left = nullptr;
        FibNode* right = nullptr;

        FibNode(double k, int v)
        {
            key = k;
            value = v;
            left = right = this;
        }
    };

    FibNode* minNode = nullptr;
    int nodeCount = 0;

    void addToRootList(FibNode* x)
    {
        if (!minNode)
        {
            minNode = x;
        }
        else
        {
            x->left = minNode;
            x->right = minNode->right;
            minNode->right->left = x;
            minNode->right = x;
            if (x->key < minNode->key)
                minNode = x;
        }
    }

    void link(FibNode* y, FibNode* x)
    {
        // remove y from root list
        y->left->right = y->right;
        y->right->left = y->left;

        // make y child of x
        y->parent = x;

        if (!x->child)
        {
            x->child = y;
            y->left = y->right = y;
        }
        else
        {
            y->left = x->child;
            y->right = x->child->right;
            x->child->right->left = y;
            x->child->right = y;
        }

        x->degree++;
        y->marked = false;
    }

    void consolidate()
    {
        int D = 50;
        vector<FibNode*> A(D, nullptr);

        vector<FibNode*> rootList;
        FibNode* curr = minNode;
        if (curr)
        {
            do {
                rootList.push_back(curr);
                curr = curr->right;
            } while (curr != minNode);
        }

        for (FibNode* w : rootList)
        {
            FibNode* x = w;
            int d = x->degree;

            while (A[d])
            {
                FibNode* y = A[d];
                if (y->key < x->key)
                    swap(x, y);

                link(y, x);
                A[d] = nullptr;
                d++;
            }
            A[d] = x;
        }

        minNode = nullptr;

        for (FibNode* x : A)
        {
            if (x)
            {
                x->left = x->right = x;
                if (!minNode)
                    minNode = x;
                else
                {
                    x->left = minNode;
                    x->right = minNode->right;
                    minNode->right->left = x;
                    minNode->right = x;
                    if (x->key < minNode->key)
                        minNode = x;
                }
            }
        }
    }

    void cut(FibNode* x, FibNode* y)
    {
        if (x->right == x)
            y->child = nullptr;
        else
        {
            x->right->left = x->left;
            x->left->right = x->right;
            if (y->child == x)
                y->child = x->right;
        }

        y->degree--;

        x->parent = nullptr;
        x->left = x->right = x;
        x->marked = false;

        addToRootList(x);
    }

    void cascadingCut(FibNode* y)
    {
        FibNode* z = y->parent;
        if (z)
        {
            if (!y->marked)
                y->marked = true;
            else
            {
                cut(y, z);
                cascadingCut(z);
            }
        }
    }

public:
    unordered_map<int, FibNode*> storage;

    bool empty()
    {
        return minNode == nullptr;
    }

    void insert(double key, int value)
    {
        FibNode* x = new FibNode(key, value);
        addToRootList(x);
        storage[value] = x;
        nodeCount++;
    }

    BinHeapNode ExtractMin()
    {
        BinHeapNode temp;
        temp.key = 0;
        temp.value = 0;
        FibNode* z = minNode;
        if (!z)
            return temp;

        if (z->child)
        {
            FibNode* c = z->child;
            vector<FibNode*> kids;

            do {
                kids.push_back(c);
                c = c->right;
            } while (c != z->child);

            for (FibNode* x : kids)
            {
                x->parent = nullptr;
                addToRootList(x);
            }
        }

        z->left->right = z->right;
        z->right->left = z->left;

        if (z == z->right)
            minNode = nullptr;
        else
        {
            minNode = z->right;
            consolidate();
        }

        storage.erase(z->value);
        nodeCount--;

        temp.key = z->key;
        temp.value = z->value;        

        delete z;
        return temp;
    }

    void decreaseKey(int value, double newKey)
    {
        FibNode* x = storage[value];
        if (!x)
            return;

        if (newKey > x->key)
            return;

        x->key = newKey;
        FibNode* y = x->parent;

        if (y && x->key < y->key)
        {
            cut(x, y);
            cascadingCut(y);
        }

        if (x->key < minNode->key)
            minNode = x;
    }
};

#pragma once

class BinaryHeap :public ParentHeap
{
public:
    vector<BinHeapNode> heap; // the main heap

    // some basic functions
    int getParent(int inp) { return (inp - 1) / 2; }
    int getLeftChild(int inp) { return 2 * inp + 1; }
    int getRightChild(int inp) { return 2 * inp + 2; }

    void heapifyUp(int ind) 
    {
        while (ind > 0) 
        {
            int parent = getParent(ind);
            if (heap[parent].key <= heap[ind].key)
                break;
            BinHeapNode temp;
            temp.key = heap[parent].key;
            temp.value = heap[parent].value;
            heap[parent].key = heap[ind].key;
            heap[parent].value = heap[ind].value;
            heap[ind].key = temp.key;
            heap[ind].value = temp.value;
            storage[heap[parent].value] = parent;
            storage[heap[ind].value] = ind;
            ind = parent;
        }
    }

    void heapifyDown(int inp) 
    {
        while (1) 
        {
            int l_ = getLeftChild(inp);
            int r_ = getRightChild(inp);
            int smallest = inp;

            if (l_ < size && heap[l_].key < heap[smallest].key)
                smallest = l_;
            if (r_ < size && heap[r_].key < heap[smallest].key)
                smallest = r_;

            if (smallest == inp)
                break;

            BinHeapNode temp;
            temp.key = heap[inp].key;
            temp.value = heap[inp].value;
            heap[inp].key = heap[smallest].key;
            heap[inp].value = heap[smallest].value;
            heap[smallest].key = temp.key;
            heap[smallest].value = temp.value;
            storage[heap[inp].value] = inp;
            storage[heap[smallest].value] = smallest;
            inp = smallest;
        }
    }

    void insert(double key, int value) 
    {

        if (storage.count(value)) // prevent duplicates somehow, I don;t even f'ing know how >:(
            return;

        if (size < heap.size()) 
        {
            heap[size].key = key;
            heap[size].value = value;            
        }
        else 
        {
            BinHeapNode temp;
            temp.key = key;
            temp.value = value;
            heap.push_back(temp);
        }

        storage[value] = size;
        size++;
        heapifyUp(size - 1);
    }

    BinHeapNode ExtractMin() 
    {
        BinHeapNode temp;
        temp.key = -1;
        temp.value = -1;

        if (size == 0) 
            return temp;

        BinHeapNode top = heap[0];
        storage.erase(top.value);
        heap[0] = heap[size - 1];
        size-=1;

        if (size > 0) 
        {
            storage[heap[0].value] = 0;
            heapifyDown(0);
        }

        return top;
    }

    void decreaseKey(int v, double updated) 
    {
        if (storage.count(v) == 0) 
            return;
        int i = storage[v];
        heap[i].key = updated;
        heapifyUp(i);
    }

    bool empty() 
    {
        if(size==0)
            return true;
        return false;
    }
};

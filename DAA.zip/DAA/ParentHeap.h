#pragma once
using namespace std;

// some important globals
int auto_manage = 4; // 1,2,3,4


class BinHeapNode // This is a *very* important class
{//key value pair
public:
    double key;
    int value;
};

class ParentHeap
{
    public:
        int size = 0;    
        unordered_map<int, int> storage;     
        virtual void insert(double a,int b){}
        virtual void decreaseKey(int a,double b){}        
        virtual bool empty()
        {
            return true;
        }        
        virtual BinHeapNode ExtractMin()
        {
            BinHeapNode temp;
            return temp;
        }

};

﻿#pragma once
using namespace std;

Graph dijkstraTree(Graph G)
{
    int first = 0;

    // Some helping vector lists
    vector<double> dist_(G.total_vertices, (float)INT_MAX);
    vector<int> parent(G.total_vertices, -1);

    ParentHeap* heap;// selection here
    if(auto_manage == 1)
        heap = new BinaryHeap();
    else if(auto_manage == 2)
        heap = new FibHeap();    
    else if(auto_manage == 3)
        heap = new HollowHeap();    

    else // decide here
        heap = new HollowHeap();    
        

    dist_[first] = 0;
    heap->insert(0, first);

    // Main Dijkstra loop
    while (!heap->empty())
    {
        BinHeapNode node = heap->ExtractMin();
        int node_A= node.value;
        double dist = node.key;

        // Skip stale nodes
        if (dist > dist_[node_A])
            continue;
        
        for (int i = 0; i < G.graph_list[node_A].size(); i++)
        {// relaxation loop
            Edge edge_ = G.graph_list[node_A][i];
            int node_B= edge_.toNode;
            double w = edge_.weight;

            if (dist_[node_A] + w < dist_[node_B])
            {
                dist_[node_B] = dist_[node_A] + w;
                parent[node_B] = node_A;

                if (heap->storage.count(node_B))
                    heap->decreaseKey(node_B, dist_[node_B]);
                else
                    heap->insert(dist_[node_B], node_B);
            }
        }
    }

    Graph G_;
    G_.setSizeInitially(G.total_vertices);

    for (int node_B= 0; node_B< G.total_vertices; node_B++)
    {
        int node_A= parent[node_B];
        if (node_A== -1) 
            continue; // skip first node

        for (int j = 0; j < G.graph_list[node_A].size(); j++)
        {
            const Edge& edge_ = G.graph_list[node_A][j];
            if (edge_.toNode == node_B)
            {
                G_.insertEdge(node_A, edge_);
                break;
            }
        }
    }

    return G_;
}

void printGraph(Graph G)
{// straight from GPT
    cout << "Total edges in ST = " << G.total_edges << "\n\n";

    for (int node_A = 0; node_A< G.graph_list.size(); node_A++)
    {
        cout << "Node " << node_A<< " has edges:\n";

        if (G.graph_list[node_A].empty())
        {
            cout << "  (none)\n\n";
            continue;
        }

        for (int j = 0; j < G.graph_list[node_A].size(); j++)
        {
            const Edge& edge_ = G.graph_list[node_A][j];
            cout << "  --> " << edge_.toNode 
                 << "   (weight = " << edge_.weight << ")\n";
        }

        cout << "\n";
    }
}
void writeGraphToFile(Graph G,string name, string dir)
{
    int loading_count = 0;
    ofstream out(dir+"Processed_"+name,ios::trunc);
    cout << "\t\n0/" << G.total_edges << "\n";
	cout << "\t\nWriting.";

    out << G.total_vertices << " " << G.total_edges << "\n";
    for (int i = 0; i < G.graph_list.size(); i++)
    {
        if (G.graph_list[i].empty())
            continue;

        for (int j = 0; j < G.graph_list[i].size(); j++)
        {
            Edge edge_ = G.graph_list[i][j];
            out << i << " " << edge_.toNode << " " << edge_.weight << "\n";
        }
		if (loading_count % 10000 == 0)
			cout << ".";

        if(loading_count > 100000)
        {
            loading_count = 0;
			system("clear");
			cout << "\t\n" << i << "/" << G.total_edges << "\n";
			cout << "\t\nWriting.";
        }
        loading_count++;
    }
	system("clear");
	cout << "\t\n" << G.total_edges << "/" << G.total_edges << "\n";
	cout << "\t\nData Successfully written.";

    out.close();
}